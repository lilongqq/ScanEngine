import struct
from xdrlib import Packer, Unpacker, ConversionError
from xdrlib import Error as XDRError
from . import const
from . import rtypes as types


class nullclass(object):
    pass


class nfs_pro_v3Packer(Packer):
    pack_hyper = Packer.pack_hyper
    pack_string = Packer.pack_string
    pack_int = Packer.pack_int
    pack_float = Packer.pack_float
    pack_uint = Packer.pack_uint
    pack_opaque = Packer.pack_opaque
    pack_double = Packer.pack_double
    pack_unsigned = Packer.pack_uint
    pack_quadruple = Packer.pack_double
    pack_uhyper = Packer.pack_uhyper
    pack_bool = Packer.pack_bool
    pack_uint32 = pack_uint64 = pack_uint

    def pack_uint64(self, x):
        try:
            self._Packer__buf.write(struct.pack('>Q', x))
        except struct.error as e:
            raise ConversionError(e.args[0])

    def pack_filename3(self, data):
        self.pack_string(data)

    def pack_nfspath3(self, data):
        self.pack_string(data)

    def pack_cookieverf3(self, data):
        self.pack_fopaque(const.NFS3_COOKIEVERFSIZE, data)

    def pack_createverf3(self, data):
        self.pack_fopaque(const.NFS3_CREATEVERFSIZE, data)

    def pack_ftype3(self, data):
        if data not in [const.NF3REG, const.NF3DIR, const.NF3BLK, const.NF3CHR, const.NF3LNK, const.NF3SOCK,
                        const.NF3FIFO]:
            raise XDRError('value=%s not in enum ftype3' % data)
        self.pack_int(data)

    def pack_specdata3(self, data):
        if data.major is None:
            raise TypeError('data.major == None')
        self.pack_uint32(data.major)
        if data.minor is None:
            raise TypeError('data.minor == None')
        self.pack_uint32(data.minor)

    def pack_nfs_fh3(self, data):
        if data.data is None:
            raise TypeError('data.data == None')
        if len(data.data) > const.NFS3_FHSIZE:
            raise XDRError('array length too long for data.data')
        self.pack_opaque(data.data)

    def pack_nfstime3(self, data):
        if data.seconds is None:
            raise TypeError('data.seconds == None')
        self.pack_uint32(data.seconds)
        if data.nseconds is None:
            raise TypeError('data.nseconds == None')
        self.pack_uint32(data.nseconds)

    def pack_set_uint32(self, data):
        if data.set is None:
            raise TypeError('data.set == None')
        self.pack_bool(data.set)
        if data.set == const.TRUE:
            if data.val is None:
                raise TypeError('data.val == None')
            self.pack_uint32(data.val)
        else:
            pass

    def pack_set_uint64(self, data):
        if data.set is None:
            raise TypeError('data.set == None')
        self.pack_bool(data.set)
        if data.set == const.TRUE:
            if data.val is None:
                raise TypeError('data.val == None')
            self.pack_uint64(data.val)
        else:
            pass

    def pack_time_how(self, data):
        if data not in [const.DONT_CHANGE, const.SET_TO_SERVER_TIME, const.SET_TO_CLIENT_TIME]:
            raise XDRError('value=%s not in enum time_how' % data)
        self.pack_int(data)

    def pack_set_time(self, data):
        if data.set is None:
            raise TypeError('data.set == None')
        self.pack_time_how(data.set)
        if data.set == const.SET_TO_CLIENT_TIME:
            if data.time is None:
                raise TypeError('data.time == None')
            self.pack_nfstime3(data.time)
        else:
            pass

    def pack_sattr3(self, data):
        if data.mode is None:
            raise TypeError('data.mode == None')
        self.pack_set_uint32(data.mode)
        if data.uid is None:
            raise TypeError('data.uid == None')
        self.pack_set_uint32(data.uid)
        if data.gid is None:
            raise TypeError('data.gid == None')
        self.pack_set_uint32(data.gid)
        if data.size is None:
            raise TypeError('data.size == None')
        self.pack_set_uint64(data.size)
        if data.atime is None:
            raise TypeError('data.atime == None')
        self.pack_set_time(data.atime)
        if data.mtime is None:
            raise TypeError('data.mtime == None')
        self.pack_set_time(data.mtime)

    def pack_diropargs3(self, data):
        if data.dir is None:
            raise TypeError('data.dir == None')
        self.pack_nfs_fh3(data.dir)
        if data.name is None:
            raise TypeError('data.name == None')
        self.pack_filename3(data.name)

    def pack_sattrguard3(self, data):
        if data.check is None:
            raise TypeError('data.check == None')
        self.pack_bool(data.check)
        if data.check == const.TRUE:
            if data.ctime is None:
                raise TypeError('data.ctime == None')
            self.pack_nfstime3(data.ctime)
        elif data.check == const.FALSE:
            pass
        else:
            raise XDRError('bad switch=%s' % data.check)

    def pack_setattr3args(self, data):
        if data.object is None:
            raise TypeError('data.object == None')
        self.pack_nfs_fh3(data.object)
        if data.new_attributes is None:
            raise TypeError('data.new_attributes == None')
        self.pack_sattr3(data.new_attributes)
        if data.guard is None:
            raise TypeError('data.guard == None')
        self.pack_sattrguard3(data.guard)

    def pack_access3args(self, data):
        if data.object is None:
            raise TypeError('data.object == None')
        self.pack_nfs_fh3(data.object)
        if data.access is None:
            raise TypeError('data.access == None')
        self.pack_uint32(data.access)

    def pack_read3args(self, data):
        if data.file is None:
            raise TypeError('data.file == None')
        self.pack_nfs_fh3(data.file)
        if data.offset is None:
            raise TypeError('data.offset == None')
        self.pack_uint64(data.offset)
        if data.count is None:
            raise TypeError('data.count == None')
        self.pack_uint32(data.count)

    def pack_stable_how(self, data):
        if data not in [const.UNSTABLE, const.DATA_SYNC, const.FILE_SYNC]:
            raise XDRError('value=%s not in enum stable_how' % data)
        self.pack_int(data)

    def pack_write3args(self, data):
        if data.file is None:
            raise TypeError('data.file == None')
        self.pack_nfs_fh3(data.file)
        if data.offset is None:
            raise TypeError('data.offset == None')
        self.pack_uint64(data.offset)
        if data.count is None:
            raise TypeError('data.count == None')
        self.pack_uint32(data.count)
        if data.stable is None:
            raise TypeError('data.stable == None')
        self.pack_stable_how(data.stable)
        if data.data is None:
            raise TypeError('data.data == None')
        self.pack_opaque(data.data)

    def pack_createmode3(self, data):
        if data not in [const.UNCHECKED, const.GUARDED, const.EXCLUSIVE]:
            raise XDRError('value=%s not in enum createmode3' % data)
        self.pack_int(data)

    def pack_createhow3(self, data):
        if data.mode is None:
            raise TypeError('data.mode == None')
        self.pack_createmode3(data.mode)
        if data.mode == const.UNCHECKED or data.mode == const.GUARDED:
            if data.obj_attributes is None:
                raise TypeError('data.obj_attributes == None')
            self.pack_sattr3(data.obj_attributes)
        elif data.mode == const.EXCLUSIVE:
            if data.verf is None:
                raise TypeError('data.verf == None')
            self.pack_createverf3(data.verf)
        else:
            raise XDRError('bad switch=%s' % data.mode)

    def pack_create3args(self, data):
        if data.where is None:
            raise TypeError('data.where == None')
        self.pack_diropargs3(data.where)
        if data.how is None:
            raise TypeError('data.how == None')
        self.pack_createhow3(data.how)

    def pack_mkdir3args(self, data):
        if data.where is None:
            raise TypeError('data.where == None')
        self.pack_diropargs3(data.where)
        if data.attributes is None:
            raise TypeError('data.attributes == None')
        self.pack_sattr3(data.attributes)

    def pack_symlinkdata3(self, data):
        if data.symlink_attributes is None:
            raise TypeError('data.symlink_attributes == None')
        self.pack_sattr3(data.symlink_attributes)
        if data.symlink_data is None:
            raise TypeError('data.symlink_data == None')
        self.pack_nfspath3(data.symlink_data)

    def pack_symlink3args(self, data):
        if data.where is None:
            raise TypeError('data.where == None')
        self.pack_diropargs3(data.where)
        if data.symlink is None:
            raise TypeError('data.symlink == None')
        self.pack_symlinkdata3(data.symlink)

    def pack_devicedata3(self, data):
        if data.dev_attributes is None:
            raise TypeError('data.dev_attributes == None')
        self.pack_sattr3(data.dev_attributes)
        if data.spec is None:
            raise TypeError('data.spec == None')
        self.pack_specdata3(data.spec)

    def pack_mknoddata3(self, data):
        if data.type is None:
            raise TypeError('data.type == None')
        self.pack_ftype3(data.type)
        if data.type == const.NF3CHR or data.type == const.NF3BLK:
            if data.device is None:
                raise TypeError('data.device == None')
            self.pack_devicedata3(data.device)
        elif data.type == const.NF3SOCK or data.type == const.NF3FIFO:
            if data.pipe_attributes is None:
                raise TypeError('data.pipe_attributes == None')
            self.pack_sattr3(data.pipe_attributes)
        else:
            pass

    def pack_mknod3args(self, data):
        if data.where is None:
            raise TypeError('data.where == None')
        self.pack_diropargs3(data.where)
        if data.what is None:
            raise TypeError('data.what == None')
        self.pack_mknoddata3(data.what)

    def pack_rename3args(self, data):
        if data.from_v is None:
            raise TypeError('data.from == None')
        self.pack_diropargs3(data.from_v)
        if data.to is None:
            raise TypeError('data.to == None')
        self.pack_diropargs3(data.to)

    def pack_link3args(self, data):
        if data.file is None:
            raise TypeError('data.file == None')
        self.pack_nfs_fh3(data.file)
        if data.link is None:
            raise TypeError('data.link == None')
        self.pack_diropargs3(data.link)

    def pack_readdirplus3args(self, data):
        if data.dir is None:
            raise TypeError('data.dir == None')
        self.pack_nfs_fh3(data.dir)
        if data.cookie is None:
            raise TypeError('data.cookie == None')
        self.pack_uint64(data.cookie)
        if data.cookieverf is None:
            raise TypeError('data.cookieverf == None')
        self.pack_cookieverf3(data.cookieverf)
        if data.dircount is None:
            raise TypeError('data.dircount == None')
        self.pack_uint32(data.dircount)
        if data.maxcount is None:
            raise TypeError('data.maxcount == None')
        self.pack_uint32(data.maxcount)

    def pack_commit3args(self, data):
        if data.file is None:
            raise TypeError('data.file == None')
        self.pack_nfs_fh3(data.file)
        if data.offset is None:
            raise TypeError('data.offset == None')
        self.pack_uint64(data.offset)
        if data.count is None:
            raise TypeError('data.count == None')
        self.pack_uint32(data.count)

    def pack_fhandle3(self, data):
        if len(data) > const.NFS3_FHSIZE:
            raise XDRError('array length too long for data')
        self.pack_opaque(data)


class nfs_pro_v3Unpacker(Unpacker):
    unpack_hyper = Unpacker.unpack_hyper
    unpack_string = Unpacker.unpack_string
    unpack_int = Unpacker.unpack_int
    unpack_float = Unpacker.unpack_float
    unpack_uint = Unpacker.unpack_uint
    unpack_opaque = Unpacker.unpack_opaque
    unpack_double = Unpacker.unpack_double
    unpack_unsigned = Unpacker.unpack_uint
    unpack_quadruple = Unpacker.unpack_double
    unpack_uhyper = Unpacker.unpack_uhyper
    unpack_bool = Unpacker.unpack_bool
    unpack_uint32 = unpack_uint

    def unpack_uint64(self):
        i = self._Unpacker__pos
        self._Unpacker__pos = j = i + 8
        data = self._Unpacker__buf[i:j]
        if len(data) < 8:
            raise EOFError
        return struct.unpack('>Q', data)[0]

    def unpack_filename3(self):
        data = self.unpack_string()
        return data

    def unpack_nfspath3(self):
        data = self.unpack_string()
        return data

    def unpack_cookieverf3(self):
        data = self.unpack_fopaque(const.NFS3_COOKIEVERFSIZE)
        return data

    def unpack_createverf3(self):
        data = self.unpack_fopaque(const.NFS3_CREATEVERFSIZE)
        return data

    def unpack_writeverf3(self):
        data = self.unpack_fopaque(const.NFS3_WRITEVERFSIZE)
        return data

    def unpack_nfsstat3(self):
        data = self.unpack_int()
        if data not in [const.NFS3_OK, const.NFS3ERR_PERM, const.NFS3ERR_NOENT, const.NFS3ERR_IO, const.NFS3ERR_NXIO,
                        const.NFS3ERR_ACCES, const.NFS3ERR_EXIST, const.NFS3ERR_XDEV, const.NFS3ERR_NODEV,
                        const.NFS3ERR_NOTDIR, const.NFS3ERR_ISDIR, const.NFS3ERR_INVAL, const.NFS3ERR_FBIG,
                        const.NFS3ERR_NOSPC, const.NFS3ERR_ROFS, const.NFS3ERR_MLINK, const.NFS3ERR_NAMETOOLONG,
                        const.NFS3ERR_NOTEMPTY, const.NFS3ERR_DQUOT, const.NFS3ERR_STALE, const.NFS3ERR_REMOTE,
                        const.NFS3ERR_BADHANDLE, const.NFS3ERR_NOT_SYNC, const.NFS3ERR_BAD_COOKIE,
                        const.NFS3ERR_NOTSUPP, const.NFS3ERR_TOOSMALL, const.NFS3ERR_SERVERFAULT, const.NFS3ERR_BADTYPE,
                        const.NFS3ERR_JUKEBOX]:
            raise XDRError('value=%s not in enum nfsstat3' % data)
        return data

    def unpack_ftype3(self):
        data = self.unpack_int()
        if data not in [const.NF3REG, const.NF3DIR, const.NF3BLK, const.NF3CHR, const.NF3LNK, const.NF3SOCK,
                        const.NF3FIFO]:
            raise XDRError('value=%s not in enum ftype3' % data)
        return data

    def unpack_specdata3(self, data_format='json'):
        data = types.specdata3()
        data.major = self.unpack_uint32()
        data.minor = self.unpack_uint32()
        return data.__dict__ if data_format == 'json' else data

    def unpack_nfs_fh3(self, data_format='json'):
        data = types.nfs_fh3()
        data.data = bytes(self.unpack_opaque())
        if len(data.data) > const.NFS3_FHSIZE:
            raise XDRError('array length too long for data.data')
        return data.__dict__ if data_format == 'json' else data

    def unpack_nfstime3(self, data_format='json'):
        data = types.nfstime3()
        data.seconds = self.unpack_uint32()
        data.nseconds = self.unpack_uint32()
        return data.__dict__ if data_format == 'json' else data

    def unpack_fattr3(self, data_format='json'):
        data = types.fattr3()
        data.type = self.unpack_ftype3()
        data.mode = self.unpack_uint32()
        data.nlink = self.unpack_uint32()
        data.uid = self.unpack_uint32()
        data.gid = self.unpack_uint32()
        data.size = self.unpack_uint64()
        data.used = self.unpack_uint64()
        data.rdev = self.unpack_specdata3()
        data.fsid = self.unpack_uint64()
        data.fileid = self.unpack_uint64()
        data.atime = self.unpack_nfstime3()
        data.mtime = self.unpack_nfstime3()
        data.ctime = self.unpack_nfstime3()
        return data.__dict__ if data_format == 'json' else data

    def unpack_post_op_attr(self, data_format='json'):
        data = types.post_op_attr()
        data.present = self.unpack_bool()
        if data.present == const.TRUE:
            data.attributes = self.unpack_fattr3(data_format)
        elif data.present == const.FALSE:
            pass
        else:
            raise XDRError('bad switch=%s' % data.present)
        return data.__dict__ if data_format == 'json' else data

    def unpack_wcc_attr(self, data_format='json'):
        data = types.wcc_attr()
        data.size = self.unpack_uint64()
        data.mtime = self.unpack_nfstime3(data_format)
        data.ctime = self.unpack_nfstime3(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_pre_op_attr(self, data_format='json'):
        data = types.pre_op_attr()
        data.present = self.unpack_bool()
        if data.present == const.TRUE:
            data.attributes = self.unpack_wcc_attr(data_format)
        elif data.present == const.FALSE:
            pass
        else:
            raise XDRError('bad switch=%s' % data.present)
        return data.__dict__ if data_format == 'json' else data

    def unpack_wcc_data(self, data_format='json'):
        data = types.wcc_data()
        data.before = self.unpack_pre_op_attr(data_format)
        data.after = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_post_op_fh3(self, data_format='json'):
        data = types.post_op_fh3()
        data.present = self.unpack_bool()
        if data.present == const.TRUE:
            data.handle = self.unpack_nfs_fh3(data_format)
        elif data.present == const.FALSE:
            pass
        else:
            raise XDRError('bad switch=%s' % data.present)
        return data.__dict__ if data_format == 'json' else data

    def unpack_set_uint32(self, data_format='json'):
        data = types.set_uint32()
        data.set = self.unpack_bool()
        if data.set == const.TRUE:
            data.val = self.unpack_uint32()
        else:
            pass
        return data.__dict__ if data_format == 'json' else data

    def unpack_set_uint64(self, data_format='json'):
        data = types.set_uint64()
        data.set = self.unpack_bool()
        if data.set == const.TRUE:
            data.val = self.unpack_uint64()
        else:
            pass
        return data.__dict__ if data_format == 'json' else data

    def unpack_time_how(self):
        data = self.unpack_int()
        if data not in [const.DONT_CHANGE, const.SET_TO_SERVER_TIME, const.SET_TO_CLIENT_TIME]:
            raise XDRError('value=%s not in enum time_how' % data)
        return data

    def unpack_set_time(self, data_format='json'):
        data = types.set_time()
        data.set = self.unpack_time_how()
        if data.set == const.SET_TO_CLIENT_TIME:
            data.time = self.unpack_nfstime3(data_format)
        else:
            pass
        return data.__dict__ if data_format == 'json' else data

    def unpack_sattr3(self, data_format='json'):
        data = types.sattr3()
        data.mode = self.unpack_set_uint32()
        data.uid = self.unpack_set_uint32()
        data.gid = self.unpack_set_uint32()
        data.size = self.unpack_set_uint64()
        data.atime = self.unpack_set_time(data_format)
        data.mtime = self.unpack_set_time(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_getattr3res(self, data_format='json'):
        data = types.getattr3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.attributes = self.unpack_fattr3(data_format)
        else:
            pass
        return data.__dict__ if data_format == 'json' else data

    def unpack_sattrguard3(self, data_format='json'):
        data = types.sattrguard3()
        data.check = self.unpack_bool()
        if data.check == const.TRUE:
            data.ctime = self.unpack_nfstime3(data_format)
        elif data.check == const.FALSE:
            pass
        else:
            raise XDRError('bad switch=%s' % data.check)
        return data.__dict__ if data_format == 'json' else data

    def unpack_wccdata3res(self, category, data_format='json'):
        data = types.wcc_data3res(category=category)
        data.status = self.unpack_nfsstat3()
        data.wcc_data = self.unpack_wcc_data(data_format)
        if data_format == 'json':
            res = data.__dict__
            res.pop("category")
            if res["status"] == const.NFS3_OK:
                res["resok"] = res["wcc_data"]
            else:
                res["resfail"] = res["wcc_data"]
            res.pop("wcc_data")
            return res
        else:
            return data

    def unpack_setattr3res(self, data_format='json'):
        return self.unpack_wccdata3res(category='setattr3res', data_format=data_format)

    def unpack_lookup3resok(self, data_format='json'):
        data = types.lookup3resok()
        data.object = self.unpack_nfs_fh3(data_format)
        data.obj_attributes = self.unpack_post_op_attr(data_format)
        data.dir_attributes = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_lookup3res(self, data_format='json'):
        data = types.lookup3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_lookup3resok(data_format)
        else:
            data.resfail = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_access3resok(self, data_format='json'):
        data = types.access3resok()
        data.obj_attributes = self.unpack_post_op_attr(data_format)
        data.access = self.unpack_uint32()
        return data.__dict__ if data_format == 'json' else data

    def unpack_access3res(self, data_format='json'):
        data = types.access3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_access3resok(data_format)
        else:
            data.resfail = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_readlink3resok(self, data_format='json'):
        data = types.readlink3resok()
        data.symlink_attributes = self.unpack_post_op_attr(data_format)
        data.data = self.unpack_nfspath3()
        return data.__dict__ if data_format == 'json' else data

    def unpack_readlink3res(self, data_format='json'):
        data = types.readlink3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_readlink3resok(data_format)
        else:
            data.resfail = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_read3resok(self, data_format='json'):
        data = types.read3resok()
        data.file_attributes = self.unpack_post_op_attr(data_format)
        data.count = self.unpack_uint32()
        data.eof = self.unpack_bool()
        data.data = self.unpack_opaque()
        return data.__dict__ if data_format == 'json' else data

    def unpack_read3res(self, data_format='json'):
        data = types.read3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_read3resok(data_format)
        else:
            data.resfail = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_stable_how(self):
        data = self.unpack_int()
        if data not in [const.UNSTABLE, const.DATA_SYNC, const.FILE_SYNC]:
            raise XDRError('value=%s not in enum stable_how' % data)
        return data

    def unpack_write3resok(self, data_format='json'):
        data = types.write3resok()
        data.file_wcc = self.unpack_wcc_data(data_format)
        data.count = self.unpack_uint32()
        data.committed = self.unpack_stable_how()
        data.verf = self.unpack_writeverf3()
        return data.__dict__ if data_format == 'json' else data

    def unpack_write3res(self, data_format='json'):
        data = types.write3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_write3resok(data_format)
        else:
            data.resfail = self.unpack_wcc_data(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_createmode3(self):
        data = self.unpack_int()
        if data not in [const.UNCHECKED, const.GUARDED, const.EXCLUSIVE]:
            raise XDRError('value=%s not in enum createmode3' % data)
        return data

    def unpack_createhow3(self, data_format='json'):
        data = types.createhow3()
        data.mode = self.unpack_createmode3()
        if data.mode == const.UNCHECKED or data.mode == const.GUARDED:
            data.obj_attributes = self.unpack_sattr3(data_format)
        elif data.mode == const.EXCLUSIVE:
            data.verf = self.unpack_createverf3()
        else:
            raise XDRError('bad switch=%s' % data.mode)
        return data.__dict__ if data_format == 'json' else data

    def unpack_create3resok(self, data_format='json'):
        data = types.create3resok()
        data.obj = self.unpack_post_op_fh3()
        data.obj_attributes = self.unpack_post_op_attr(data_format)
        data.dir_wcc = self.unpack_wcc_data(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_create3res(self, data_format='json'):
        data = types.create3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_create3resok(data_format)
        else:
            data.resfail = self.unpack_wcc_data(data_format)
        return data.__dict__ if data_format == 'json' else data

    unpack_mkdir3res = unpack_create3res

    def unpack_symlinkdata3(self, data_format='json'):
        data = types.symlinkdata3()
        data.symlink_attributes = self.unpack_sattr3(data_format)
        data.symlink_data = self.unpack_nfspath3()
        return data.__dict__ if data_format == 'json' else data

    unpack_symlink3res = unpack_create3res

    def unpack_devicedata3(self, data_format='json'):
        data = types.devicedata3()
        data.dev_attributes = self.unpack_sattr3(data_format)
        data.spec = self.unpack_specdata3(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_mknoddata3(self, data_format='json'):
        data = types.mknoddata3()
        data.type = self.unpack_ftype3()
        if data.type == const.NF3CHR or data.type == const.NF3BLK:
            data.device = self.unpack_devicedata3(data_format)
        elif data.type == const.NF3SOCK or data.type == const.NF3FIFO:
            data.pipe_attributes = self.unpack_sattr3(data_format)
        else:
            pass
        return data.__dict__ if data_format == 'json' else data

    unpack_mknod3res = unpack_create3res

    def unpack_remove3res(self, data_format='json'):
        return self.unpack_wccdata3res(category='remove3res', data_format=data_format)

    def unpack_rmdir3res(self, data_format='json'):
        return self.unpack_wccdata3res(category='rmdir3res', data_format=data_format)

    def unpack_rename3wcc(self, data_format='json'):
        data = types.rename3wcc()
        data.fromdir_wcc = self.unpack_wcc_data(data_format)
        data.todir_wcc = self.unpack_wcc_data(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_rename3res(self, data_format='json'):
        data = types.rename3res()
        data.status = self.unpack_nfsstat3()
        if data.status == -1:
            pass
        else:
            data.res = self.unpack_rename3wcc(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_link3wcc(self, data_format='json'):
        data = types.link3wcc()
        data.file_attributes = self.unpack_post_op_attr(data_format)
        data.linkdir_wcc = self.unpack_wcc_data(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_link3res(self, data_format='json'):
        data = types.link3res()
        data.status = self.unpack_nfsstat3()
        if data.status == -1:
            pass
        else:
            data.res = self.unpack_link3wcc(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_entryplus3(self, data_format='json'):
        data = types.entryplus3()
        data.fileid = self.unpack_uint64()
        data.name = self.unpack_filename3()
        data.cookie = self.unpack_uint64()
        data.name_attributes = self.unpack_post_op_attr(data_format)
        data.name_handle = self.unpack_post_op_fh3(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_dirlistplus3(self, data_format='json'):
        data = types.dirlistplus3()
        data.entries = self.unpack_list(self.unpack_entryplus3)
        data.eof = self.unpack_bool()
        return data.__dict__ if data_format == 'json' else data

    def unpack_readdirplus3resok(self, data_format='json'):
        data = types.readdirplus3resok()
        data.dir_attributes = self.unpack_post_op_attr(data_format)
        data.cookieverf = self.unpack_cookieverf3()
        data.reply = self.unpack_dirlistplus3(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_readdirplus3res(self, data_format='json'):
        data = types.readdirplus3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_readdirplus3resok(data_format)
        else:
            data.resfail = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_fsstat3resok(self, data_format='json'):
        data = types.fsstat3resok()
        data.obj_attributes = self.unpack_post_op_attr(data_format)
        data.tbytes = self.unpack_uint64()
        data.fbytes = self.unpack_uint64()
        data.abytes = self.unpack_uint64()
        data.tfiles = self.unpack_uint64()
        data.ffiles = self.unpack_uint64()
        data.afiles = self.unpack_uint64()
        data.invarsec = self.unpack_uint32()
        return data.__dict__ if data_format == 'json' else data

    def unpack_fsstat3res(self, data_format='json'):
        data = types.fsstat3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_fsstat3resok(data_format)
        else:
            data.resfail = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_fsinfo3resok(self, data_format='json'):
        data = types.fsinfo3resok()
        data.obj_attributes = self.unpack_post_op_attr(data_format)
        data.rtmax = self.unpack_uint32()
        data.rtpref = self.unpack_uint32()
        data.rtmult = self.unpack_uint32()
        data.wtmax = self.unpack_uint32()
        data.wtpref = self.unpack_uint32()
        data.wtmult = self.unpack_uint32()
        data.dtpref = self.unpack_uint32()
        data.maxfilesize = self.unpack_uint64()
        data.time_delta = self.unpack_nfstime3(data_format)
        data.properties = self.unpack_uint32()
        return data.__dict__ if data_format == 'json' else data

    def unpack_fsinfo3res(self, data_format='json'):
        data = types.fsinfo3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_fsinfo3resok(data_format)
        else:
            data.resfail = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_pathconf3resok(self, data_format='json'):
        data = types.pathconf3resok()
        data.obj_attributes = self.unpack_post_op_attr(data_format)
        data.linkmax = self.unpack_uint32()
        data.name_max = self.unpack_uint32()
        data.no_trunc = self.unpack_bool()
        data.chown_restricted = self.unpack_bool()
        data.case_insensitive = self.unpack_bool()
        data.case_preserving = self.unpack_bool()
        return data.__dict__ if data_format == 'json' else data

    def unpack_pathconf3res(self, data_format='json'):
        data = types.pathconf3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_pathconf3resok(data_format)
        else:
            data.resfail = self.unpack_post_op_attr(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_commit3resok(self, data_format='json'):
        data = types.commit3resok()
        data.file_wcc = self.unpack_wcc_data(data_format)
        data.verf = self.unpack_writeverf3()
        return data.__dict__ if data_format == 'json' else data

    def unpack_commit3res(self, data_format='json'):
        data = types.commit3res()
        data.status = self.unpack_nfsstat3()
        if data.status == const.NFS3_OK:
            data.resok = self.unpack_commit3resok(data_format)
        else:
            data.resfail = self.unpack_wcc_data(data_format)
        return data.__dict__ if data_format == 'json' else data

    def unpack_dirpath(self):
        data = self.unpack_string()
        if len(data) > const.NFS3_MNTPATHLEN:
            raise XDRError('array length too long for data')
        return data

    def unpack_name(self):
        data = self.unpack_string()
        if len(data) > const.NFS3_MNTNAMLEN:
            raise XDRError('array length too long for data')
        return data

    def unpack_fhandle3(self):
        data = self.unpack_opaque()
        if len(data) > const.NFS3_FHSIZE:
            raise XDRError('array length too long for data')
        return data

    def unpack_mountstat3(self):
        data = self.unpack_int()
        if data not in [const.MNT3_OK, const.MNT3ERR_PERM, const.MNT3ERR_NOENT, const.MNT3ERR_IO, const.MNT3ERR_ACCES,
                        const.MNT3ERR_NOTDIR, const.MNT3ERR_INVAL, const.MNT3ERR_NAMETOOLONG, const.MNT3ERR_NOTSUPP,
                        const.MNT3ERR_SERVERFAULT]:
            raise XDRError('value=%s not in enum mountstat3' % data)
        return data

    def unpack_mountres3_ok(self, data_format='json'):
        data = types.mountres3_ok()
        data.fhandle = self.unpack_fhandle3()
        data.auth_flavors = self.unpack_array(self.unpack_int)
        return data.__dict__ if data_format == 'json' else data

    def unpack_mountres3(self, data_format='json'):
        data = types.mountres3()
        data.status = self.unpack_mountstat3()
        if data.status == const.MNT3_OK:
            data.mountinfo = self.unpack_mountres3_ok(data_format)
        else:
            pass
        return data.__dict__ if data_format == 'json' else data

    def unpack_groups(self):
        data = self.unpack_list(self.unpack_groupnode)
        return data

    def unpack_groupnode(self):
        data = types.groupnode()
        data.gr_name = self.unpack_name()
        return data

    def unpack_exports(self):
        data = self.unpack_list(self.unpack_exportnode)
        return data

    def unpack_exportnode(self):
        data = types.exportnode()
        data.ex_dir = self.unpack_dirpath()
        data.ex_groups = self.unpack_groups()
        return data
